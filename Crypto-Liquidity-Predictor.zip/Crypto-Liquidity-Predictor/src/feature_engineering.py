def add_features(df):
    df['liquidity_ratio'] = df['24h_volume'] / (df['mkt_cap'] + 1e-6)
    df['volatility'] = df[['1h', '24h', '7d']].std(axis=1)
    return df
