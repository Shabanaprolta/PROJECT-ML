# Updated Crypto Liquidity Predictor

This ML project predicts crypto liquidity based on real CoinGecko market data.

## Features

- Preprocessing and feature engineering
- Random Forest Regressor
- Streamlit Dashboard
- Docker Ready

## How to Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

Or use Docker:

```bash
docker build -t crypto-liquidity .
docker run -p 8501:8501 crypto-liquidity
```
