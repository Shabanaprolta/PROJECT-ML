import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from src.data_preprocessing import load_data
from src.feature_engineering import add_features
from src.model import train_model

st.set_page_config(page_title="Crypto Liquidity Predictor", layout="wide")
st.title("Cryptocurrency Liquidity Prediction")

uploaded_file = st.file_uploader("Upload your crypto data CSV", type=["csv"])
if uploaded_file:
    df = pd.read_csv(uploaded_file)
else:
    df = load_data("data/crypto_data.csv")

df = add_features(df)

st.subheader("Sample Data")
st.dataframe(df.head())

st.subheader("Volume & Liquidity Ratio Over Time")
fig, ax1 = plt.subplots()
ax2 = ax1.twinx()
ax1.plot(df['date'], df['24h_volume'], color='blue')
ax2.plot(df['date'], df['liquidity_ratio'], color='orange')
st.pyplot(fig)

model, mse = train_model(df)
st.subheader("Model Evaluation")
st.write(f"Mean Squared Error: **{mse:.6f}**")
